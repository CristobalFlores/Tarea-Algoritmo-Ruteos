const express = require('express')
const cors = require('cors');
const bodyParser = require("body-parser");

const { retrieveData, getStart, DisjointPaths } = require("./src/route");
const { getMapa } = require('./src/map');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'))
const port = 3000

app.get('/', (req, res) => {
  res.send('Hello World!')
})

app.get('/api/map', async (req, res, next) => {

    const respPromise = getMapa();
    respPromise.then((data) => {
        // Hacer algo con los datos obtenidos
        console.log("Datos obtenidos:");
        res.send(data)
    }).catch((error) => {
        // Manejar cualquier error que ocurra durante la resolución de la promesa
        console.error("Error al obtener datos:", error);
    });

    console.log("Se ejecuto")

    // res.send({
    //     msg : "obtenido de pana"
    // })
    // route(start, end)
    //   .then((result) => {
    //     res.status(200).json(result);
    //   })
    //   .catch((reason) => {
    //     res.status(500).json(reason);
    //   });
  });

app.get('/api/start', async(req,res,next)=>{
    
    const { start } = req.query;

    const respPromise = getStart(start);
    respPromise.then((data) => {
        // Hacer algo con los datos obtenidos
        console.log("Datos obtenidos:");
        res.send(data)
    }).catch((error) => {
        // Manejar cualquier error que ocurra durante la resolución de la promesa
        console.error("Error al obtener datos:", error);
    });
})

app.get('/api/route', async (req, res, next) => {

    const { start, end,k } = req.query;

    const respPromise = retrieveData(start,end,k);
    respPromise.then((data) => {
        // Hacer algo con los datos obtenidos
        console.log("Datos obtenidos:", data);
        res.send(data)
    }).catch((error) => {
        // Manejar cualquier error que ocurra durante la resolución de la promesa
        console.error("Error al obtener datos:", error);
    });

    console.log("Se ejecuto")

    // res.send({
    //     start : start,
    //     end : end
    // })
    // route(start, end)
    //   .then((result) => {
    //     res.status(200).json(result);
    //   })
    //   .catch((reason) => {
    //     res.status(500).json(reason);
    //   });
  });

  app.get('/api/route2', async (req, res, next) => {

    const { start, end } = req.query;

    const respPromise = DisjointPaths(start,end);

    console.log(respPromise.then(data => console.log("acasadasd", data)))

    respPromise.then((data) => {

        // Hacer algo con los datos obtenidos
        console.log("Datos obtenidos:", data);
        res.send(data)
    }).catch((error) => {
        // Manejar cualquier error que ocurra durante la resolución de la promesa
        console.error("Error al obtener datos:", error);
    });

    console.log("Se ejecuto")

    // res.send({
    //     start : start,
    //     end : end
    // })
    // route(start, end)
    //   .then((result) => {
    //     res.status(200).json(result);
    //   })
    //   .catch((reason) => {
    //     res.status(500).json(reason);
    //   });
  });



app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})