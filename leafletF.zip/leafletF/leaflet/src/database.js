const { Pool} = require('pg')

const pool = new Pool({
  user: 'test',
  database: 'test',
  password: 'test',
  port: 5432,
  host: 'localhost',
})

module.exports = { pool };
