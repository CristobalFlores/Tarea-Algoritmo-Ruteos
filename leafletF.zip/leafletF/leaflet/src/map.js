const { pool } = require("./database");

async function getMapa() {
    const query = `SELECT ST_AsGeoJSON(geom) as geometry, * FROM NETWORK;`;

    try {
        const result = await pool.query(query);

        // Verificar la estructura de result
        if (result.rows) {
            // Si result tiene una propiedad rows, entonces estamos tratando con pg-promise
            const geojson = {
                type: "FeatureCollection",
                features: result.rows.map(row => {
                    return {
                        type: "Feature",
                        geometry: JSON.parse(row.geometry),
                        properties: {
                            id: row.id,
                            // ... otras propiedades
                        }
                    };
                })
            };

            return geojson;
        } else {
            // Si result no tiene una propiedad rows, ajusta esto según la estructura de tu resultado
            console.error("La estructura del resultado no es la esperada:", result);
            return { error: "La estructura del resultado no es la esperada." };
        }
    } catch (error) {
        return { error };
    }
}

module.exports = { getMapa };
