const { pool } = require("./database");

async function getStart(start) {
    const query = `SELECT ST_X(the_geom) AS longitude, ST_Y(the_geom) AS latitude FROM geometrias_noded_vertices_pgr gnvp WHERE id = ${start};
    `;

    try {
        const result = await pool.query(query);

        // Verificar la estructura de result
        if (result.rows) {

            console.log(result.rows)


            return result.rows[0];

        } else {
            // Si result no tiene una propiedad rows, ajusta esto según la estructura de tu resultado
            console.error("La estructura del resultado no es la esperada:", result);
            return { error: "La estructura del resultado no es la esperada." };
        }
    } catch (error) {
        return { error };
    }
}

async function retrieveData(start, end, k) {
    const query = `SELECT path_id, ST_AsGeoJSON(geom) as geometry FROM pgr_KSP(
        'SELECT id, source, target, st_length(geom) as cost FROM network', ${start}, ${end}, ${k}, false) as di
        JOIN network pt
        ON di.edge = pt.id ;`;

    try {
        const result = await pool.query(query);

        // Verificar la estructura de result
        if (result.rows) {
            console.log(result.rows)
            // Si result tiene una propiedad rows, entonces estamos tratando con pg-promise
            const geojson = {
                type: "FeatureCollection",
                features: result.rows.map(row => {
                    return {
                        type: "Feature",
                        geometry: JSON.parse(row.geometry),
                        properties: {
                            path_id: row.path_id,
                            cost: row.cost,
                            // ... otras propiedades
                        }
                    };
                })
            };

            return geojson;
        } else {
            // Si result no tiene una propiedad rows, ajusta esto según la estructura de tu resultado
            console.error("La estructura del resultado no es la esperada:", result);
            return { error: "La estructura del resultado no es la esperada." };
        }
    } catch (error) {
        return { error };
    }
}



async function DisjointPaths(start, end) {
    const query = `Select path_id,ST_AsGeoJSON(geom) as geometry from pgr_edgeDisjointPaths(
        'Select     id, 
                   source, 
                   target, 
                   cost,
                   cost as rev_cost from network', 
                   ${start},        -- Nodo Inicio
                   ${end},     -- Nodo Termino
                   false) as di
        JOIN network pt
        ON di.edge = pt.id ;`;

    try {
        const result = await pool.query(query);

        // Verificar la estructura de result
        if (result.rows) {
            //console.log(result.rows)
            // Si result tiene una propiedad rows, entonces estamos tratando con pg-promise
            const geojson = {
                type: "FeatureCollection",
                features: result.rows.map(row => {
                    return {
                        type: "Feature",
                        geometry: JSON.parse(row.geometry),
                        properties: {
                            path_id: row.path_id,
                            // ... otras propiedades
                        }
                    };
                })
            };
            //console.log(geojson)

            return geojson;
        } else {
            // Si result no tiene una propiedad rows, ajusta esto según la estructura de tu resultado
            console.error("La estructura del resultado no es la esperada:", result);
            return { error: "La estructura del resultado no es la esperada." };
        }
    } catch (error) {
        return { error };
    }
}


module.exports = { retrieveData, getStart, DisjointPaths };
